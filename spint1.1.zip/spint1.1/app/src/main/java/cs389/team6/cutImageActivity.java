package cs389.team6;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class cutImageActivity extends AppCompatActivity
implements View.OnClickListener{

    private static final int IMAGE_ALBUM = 1;
    private static final int IMAGE_CAMERA = 2;
    private static final int PERMISSION_CODE = 0;
    private static final int CUT_IMAGE = 3;
    private ImageView imageView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cut_image);
        initView();
    }



    private void initView(){
        Button cutCamera = findViewById(R.id.cut_camera_id);
        Button cutAlbum = findViewById(R.id.cut_album_id);
        imageView = (ImageView) findViewById(R.id.cut_image_id);
        cutAlbum.setOnClickListener(this);
        cutCamera.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.cut_album_id:
                openImgFile();
                break;
            case R.id.cut_camera_id:
                getCameraPermission();
                break;
        }
    }

    private void openImgFile(){
        /**
         * Intent.ACTION_GET_CONTENT
         * 4.4版本后使用存在问题
         * Intent.ACTION_PICK
         * 4.4版本后使用存在问题
         *Intent.CATEGORY_OPENABLE
         */
        Intent intent = new Intent();
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        //兼容检测?>4.4
        if (Build.VERSION.SDK_INT<19){
            intent.setAction(Intent.ACTION_GET_CONTENT);
        }else {
            intent.setAction(Intent.ACTION_OPEN_DOCUMENT);
        }
        startActivityForResult(intent,IMAGE_ALBUM);
    }

    @Override
    public void onActivityResult(int requestCode , int resultCode , Intent data) {
        super.onActivityResult(requestCode , resultCode , data);
        Log.i("album","album:"+requestCode+"\t"+resultCode);
        //接收照片成功
        if(resultCode==RESULT_OK){
            switch(requestCode){
                case IMAGE_CAMERA:
                    Log.i("album","success enter IMAGE_CAMERA");
                    Bundle bundle = data.getExtras();
                    Bitmap bitmap = (Bitmap) bundle.get("data");
                    cutImage(bitmap);
                    break;
                case IMAGE_ALBUM:
                    Log.i("album","success enter IMAGE_ALBUM");
                    Log.i("album","IMAGE_ALBUM:"+data.getData().getPath());
                    Bitmap bitmapAlbum = data.getParcelableExtra("data");
                    cutImage(bitmapAlbum);
                    break;
                case CUT_IMAGE:
                    Log.i("album","success enter IMAGE_ALBUM");
                    Bitmap cutBitmap = data.getParcelableExtra("data");
                    imageView.setImageBitmap(cutBitmap);
                    break;
            }
        }
    }


    private void openCamera() {
        /**
         * android.media.action.STILL_IMAGE_CAMERA
         * 会在拍摄后一直停留在相机界面
         */
        Intent cameraIntent =
                new Intent("android.media.action.IMAGE_CAPTURE");
        startActivityForResult(cameraIntent, IMAGE_CAMERA);
        //相机录音etc都用startActivityForResult
    }


    private void getCameraPermission(){
        if(Build.VERSION.SDK_INT>=23){
            int checkPermission = ContextCompat.checkSelfPermission(
                    this, Manifest.permission.CAMERA
            );
            if(checkPermission != PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.CAMERA},
                        PERMISSION_CODE);
                return;
            }else {
                openCamera();
            }
        }else {
            openCamera();
        }
    }

    //@Override
    protected void onRequestPermissionResult(int requestCode,
                                             String[] permissions,
                                             int[] grantResults){
        switch (requestCode){
            case PERMISSION_CODE:
                for(int i=0;i<grantResults.length;i++){
                    if(grantResults[i]==PackageManager.PERMISSION_GRANTED){
                        Toast.makeText(this ,
                                " get permission successfully",
                                Toast.LENGTH_LONG).show();
                        openCamera();
                    }else{
                        Toast.makeText(this,
                                "Failed to get permission",
                                Toast.LENGTH_LONG).show();
                    }
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode,
                        permissions,grantResults);
        }

    }

    private void cutImage(Bitmap bitmap){
        Intent intent = new Intent();
        intent.setAction("com.android.camera.action.CROP");
        intent.setType("image/*");
        intent.putExtra("data",bitmap);
        intent.putExtra("crop","true");

        intent.putExtra("aspectX",1);
        intent.putExtra("outputX",150);
        intent.putExtra("outputX",150);
        intent.putExtra("return-data",true);

        startActivityForResult(intent,CUT_IMAGE);


    }


}