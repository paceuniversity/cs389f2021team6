package cs389.team6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

/**
 * debug on real android phone!!!
 * this activity won't work on VM due to
 */
public class albumActivity extends AppCompatActivity
        implements View.OnClickListener{

    private static final int IMAGE_ALBUM = 12;
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_album);
        initView();
    }

    @Override
    public void onClick(View view) {
        openImgFile();
    }

    private void openImgFile(){
        /**
         * Intent.ACTION_GET_CONTENT
         * 4.4版本后使用存在问题
         * Intent.ACTION_PICK
         * 4.4版本后使用存在问题
         *Intent.CATEGORY_OPENABLE
         */
        Intent intent = new Intent();
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        //兼容检测?>4.4
        if (Build.VERSION.SDK_INT<19){
            intent.setAction(Intent.ACTION_GET_CONTENT);
        }else {
            intent.setAction(Intent.ACTION_OPEN_DOCUMENT);
        }
        startActivityForResult(intent,IMAGE_ALBUM);
    }

    private void initView(){
        Button button = findViewById(R.id.album_botton_id);
        imageView = findViewById(R.id.album_photo);
        button.setOnClickListener(this);
    }

    @Override
    public void onActivityResult(int requestCode , int resultCode , Intent data) {
        super.onActivityResult(requestCode , resultCode , data);

        //接收照片成功
        if(resultCode==IMAGE_ALBUM && resultCode==RESULT_OK){

            //Bitmap albumBitmap = data.getParcelableExtra("data");
            Bundle bundle = data.getExtras();
            Bitmap bitmap = (Bitmap) bundle.get("data");
            imageView.setImageBitmap(bitmap);
            //imageView.setImageBitmap(albumBitmap);
        }
    }




}